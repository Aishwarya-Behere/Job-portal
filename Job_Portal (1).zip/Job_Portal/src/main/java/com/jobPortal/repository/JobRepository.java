package com.jobPortal.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.jobPortal.entities.Company;
import com.jobPortal.entities.Industry;
import com.jobPortal.entities.Job;
import com.jobPortal.entities.JobType;
import com.jobPortal.entities.Status;

import jakarta.transaction.Transactional;

public interface JobRepository extends JpaRepository<Job, Long> {
	List<Job> findByLocation(String Location);
	List<Job> findAll();
	Job findByCompanyIdAndTitle(Long companyId, String title);
	
	
	Long deleteByJobTypeAndCompanyId(JobType jobtype, Long companyId);

	
	@Query("""
		    SELECT j
		    FROM Job j
		    WHERE j.company.industry = :industry
		    AND j.salary <= :salary
		""")
	List<Job> getMinimumSalWithIndustry(@Param("industry") Industry industry, @Param("salary") Double salary);
	
//	List<Job> findByStatus();
	
	
	
}
