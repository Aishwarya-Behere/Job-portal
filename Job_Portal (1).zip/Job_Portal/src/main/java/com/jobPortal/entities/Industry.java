package com.jobPortal.entities;

public enum Industry {
	Education , Pharmaceutical , Hospitality , Information_Technology,  Banking , Healthcare
}
