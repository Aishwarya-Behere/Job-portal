package com.jobPortal.entities;

import java.time.LocalDateTime;

import jakarta.annotation.Generated;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="company")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class Company {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="name", unique = true)
	private String name;
	
	@Column(name="location")
	private String location;
	
	@Column(name="email", unique = true)
	private String email;
	
	@Column(name="created_on")
	private LocalDateTime createdOn;
	
	@Enumerated(EnumType.STRING)
	private Industry industry;
	

}
