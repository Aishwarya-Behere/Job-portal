package com.jobPortal.entities;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.annotation.Generated;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(name="Job")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Job {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="job_title")
	private String title;
	
	@Column(name="job_description")
	private String description;
	
	@Column(name="salary")
	private Double salary;
	
	@Column(name="job_location")
	private String location;
	
	@Column(name="posted_date")
	private LocalDateTime postedDate;
	
	@Enumerated(EnumType.STRING)
	private JobType jobType;
	
	@Enumerated(EnumType.STRING)
	private Status status;
	
	@ManyToOne
	@JoinColumn(name = "company_id")
	private Company company;

}
