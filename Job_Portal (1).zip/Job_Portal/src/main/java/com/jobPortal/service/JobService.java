package com.jobPortal.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.jobPortal.dtos.PostJobRequest;
import com.jobPortal.entities.Company;
import com.jobPortal.entities.Industry;
import com.jobPortal.entities.Job;
import com.jobPortal.entities.JobType;
import com.jobPortal.entities.Status;
import com.jobPortal.repository.JobRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class JobService {
	
	private final JobRepository jobRepo;
	
	public List<Job> getJobByLoc(String location){
		return jobRepo.findByLocation(location);
	}
	
	public String addJob(PostJobRequest request) {
		Job job = new Job();

	    job.setTitle(request.getTitle());
	    job.setDescription(request.getDescription());
	    job.setSalary(request.getSalary());
	    job.setLocation(request.getLocation());
	    job.setJobType(request.getJobType());
	    job.setCompany(request.getCompany());
	    job.setPostedDate(LocalDateTime.now());
	    job.setStatus(Status.AVAILABLE);

	    jobRepo.save(job);

	    return "Job added successfully";
	}
	
	public List<Job> getAllJobs(){
		return jobRepo.findAll();
	}
	
	public String deleteJob(JobType jobtype, Long id) {
		long deleteCount = jobRepo.deleteByJobTypeAndCompanyId(jobtype, id);
		System.out.println(deleteCount);
		if(deleteCount>0){
			
			return "deleted successfully";
			
		}
		return "data not found";
		
		
	}
	
	public String updateSalary(String jobTitle, Long companyId, Double salary) {
		Job job = jobRepo.findByCompanyIdAndTitle(companyId, jobTitle);
		if(job!=null) {
			job.setSalary(salary);
			return "update successfully";
		}
		return "data not found";
	}
	
	public List<Job> getMinimumSal(Industry industry, Double salary) {
		List<Job> job = jobRepo.getMinimumSalWithIndustry(industry, salary);
		System.out.println(job);
		if(job!=null) {
			return job;
		}
		return null;
		
	}
	
	public String updateJobStatus() {
		List<Job> jobs = jobRepo.findAll();
		for(Job j: jobs) {
			if(j.getStatus().equals(Status.AVAILABLE)) {
				j.setStatus(Status.UNAVAILABLE);
			}
		}
		jobRepo.saveAll(jobs);							
		return "updated Successfully";
	}
}


