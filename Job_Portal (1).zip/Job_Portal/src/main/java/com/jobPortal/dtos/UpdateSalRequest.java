package com.jobPortal.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@AllArgsConstructor
@Getter
@Setter
@ToString
public class UpdateSalRequest {
	
	private String jobTitle;
	private Long companyid;
	private Double salary;
	

}
