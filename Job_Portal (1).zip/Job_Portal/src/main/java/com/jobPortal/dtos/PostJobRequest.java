package com.jobPortal.dtos;

import com.jobPortal.entities.Company;
import com.jobPortal.entities.JobType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class PostJobRequest {
	
	//company id , title , description ,salary,location, jobType

	private String title;
	
	private String description;
	
	private double salary;
	
	private String location;
	
	private JobType jobType;
	private Company company;

}
