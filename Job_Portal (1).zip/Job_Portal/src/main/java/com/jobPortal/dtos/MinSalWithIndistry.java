package com.jobPortal.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class MinSalWithIndistry {

	private String industry;
	private Double salary;
	
	
}
