package com.jobPortal.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jobPortal.dtos.MinSalWithIndistry;
import com.jobPortal.dtos.PostJobRequest;
import com.jobPortal.dtos.UpdateSalRequest;
import com.jobPortal.entities.Company;
import com.jobPortal.entities.Industry;
import com.jobPortal.entities.Job;
import com.jobPortal.entities.JobType;
import com.jobPortal.service.JobService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/job")
@RequiredArgsConstructor
public class JobController {
	private final JobService jobService;
	
	
	//testing Server
	@GetMapping("/test")
	public String test() {
		System.out.println("Test");
		return "Testing app";
	}
	
	//Find job by location
	@GetMapping("/{location}")
	public ResponseEntity<?> getJobs(@PathVariable String location){
		
		List<Job> job = jobService.getJobByLoc(location);
		return ResponseEntity.ok(job);
	}
	
	
	//Post new job opening
	@PostMapping("/postjob")
	public String postJobs(@RequestBody PostJobRequest req) {
		System.out.println(req);
		return jobService.addJob(req);
	}
	
	//List all companies by specified industry type & location
	@GetMapping("/alljobs")
	public ResponseEntity<?> getJobs(){
		return ResponseEntity.ok(jobService.getAllJobs());
	}
	
	
	//Delete all jobs of the specified job type , of specified company
	@DeleteMapping("/deletejob/{jobtype}/{companyid}")
	public String deleteJob(@PathVariable JobType jobtype, @PathVariable Long companyid) {
		return jobService.deleteJob(jobtype, companyid);
		
	}
	
	//Update salaries of the job , posted by a specific company , for specific job title
	@PutMapping("/updatesalary")
	public String updateSal(@RequestBody UpdateSalRequest req) {
		System.out.println(req);
		return jobService.updateSalary(req.getJobTitle(), req.getCompanyid(), req.getSalary());
	}
	
	
	//List all the jobs , from specific industry type & having minimum specified salary.
	@PostMapping("/getMinimumSal")
	public ResponseEntity<?> getSalWithIndustry(@RequestBody MinSalWithIndistry req) {
		
		System.out.println(req.getIndustry()+" "+req.getSalary());
		return ResponseEntity.ok(jobService.getMinimumSal(Industry.valueOf(req.getIndustry()), req.getSalary()));
		
	}
	
	//Company needs to update a job status to unavailable (position filled)
	@PutMapping("/update/status")
	public String updateJobStatus() {
		return jobService.updateJobStatus();
	}
	
	
}
